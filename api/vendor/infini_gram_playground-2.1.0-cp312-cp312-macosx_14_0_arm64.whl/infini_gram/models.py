from dataclasses import dataclass
from typing import Any, Iterable, List, Tuple, TypeVar, TypedDict

QueryIdsType = Iterable[int]
CnfType = Iterable[Iterable[QueryIdsType]]


@dataclass
class ErrorResponse(TypedDict):
    error: str 


T = TypeVar("T")
InfiniGramEngineResponse = ErrorResponse | T 

@dataclass
class DocumentWithAttribution(TypedDict):
    doc_ix: int
    doc_len: int
    disp_len: int
    disp_offset: int 
    metadata: str 
    token_ids: List[int] 
    token_offset_span_pairs: List[Tuple[int, Tuple[int, int]]] 
    total_matched_len: int 

@dataclass
class AttributionResponse(TypedDict):
    spans: List[Any]
    docs: List[DocumentWithAttribution]

@dataclass
class FindResponse(TypedDict):
    cnt: int
    segment_by_shard: List[Tuple[int, int]]
    
@dataclass 
class FindCnfResponse(TypedDict):
    cnt: int
    approx: bool
    ptrs_by_shard: List[List[int]]
    
@dataclass
class CountResponse(TypedDict): 
    count: int
    approx: bool
    
@dataclass
class ProbResponse(TypedDict):
    prompt_cnt: int
    cont_cnt: int
    prob: float

@dataclass
class DistTokenResult(TypedDict):
    cont_cnt: int
    prob: float
    
class NtdResponse(TypedDict): 
    prompt_cnt: int
    result_by_token_id: dict[int, DistTokenResult]
    approx: bool
    
class ProbResult(TypedDict):
    prompt_cnt: int
    cont_cnt: int
    prob: float
    
class InfGramProbResponse(ProbResult, TypedDict):
    suffix_len: int
    
class InfGramDistResult(TypedDict):
    prompt_cnt: int
    result_by_token_id: dict[int, DistTokenResult]
    approx: bool
    suffix_len: int
    
class DocResult(TypedDict):
    doc_ix: int
    doc_len: int
    disp_len: int
    metadata: str
    token_ids: List[int]
    
class SearchDocsResponse(TypedDict):
    cnt: int
    approx: bool
    idxs: List[int]
    documents: List[DocResult]